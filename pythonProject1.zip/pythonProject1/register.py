import pymysql
from connDB import connection
import validation

# Создание функции для регистрации нового сотрудника
import pymysql


try:
    with connection.cursor() as cursor:
        while True:

            DB = input("Авторизация (1), регистрация (2): ")
            if DB == "1":
                while True:
                    email = input("Введите логин\email: ")
                    password = input("Введите пароль: ")
                    user_autorization = f"select id from employees " \
                                   f"where (email = '{email}' and password = MD5('{password}'))"

                    cursor.execute(user_autorization)
                    user_autorization = cursor.fetchall()
                    print(user_autorization)
                    if user_autorization:
                        print("Вы вошли в личный кабинет!")
                        cursor.execute("SELECT * FROM `employees`")
                        sotrudnik_query = cursor.fetchall()
                        print("Ваше имущество:")
                        print(f"name")

                    else:
                        print("Неверный логин или пароль")

            elif DB == "2":
                while True:
                    print("Регистрация: ")
                    first_name = input("Введите имя: ")

                    while True:
                        password = input('Введите пароль: ')
                        if validation.is_valid_password(password):
                            print('Пароль надежный.')
                            break
                        else:
                            print('Пароль ненадежный! ')

                    email = input("Введите почту:")
                    name = input("Введите Имя:")
                    position_id = input("Введите должность:")
                    user_reg = f"INSERT INTO employees(email, password, name, position_id) VALUES ('{email}', MD5('{password}'), '{name}', '{position_id}')"
                    cursor.execute(user_reg)
                    connection.commit()
                    print("Регистрация выполнена успешно!")
                    break
finally:
    connection.close()


