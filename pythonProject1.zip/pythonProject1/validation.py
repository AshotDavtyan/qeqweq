import re
from validate_email import validate_email

def is_valid_password(password):
    # Проверьте, что пароль состоит как минимум из 8 символов и содержит как минимум одну заглавную букву, одну строчную букву и одну цифру.
    if re.match(r"^(?=.*[a-z])(?=.*[A-Z])[a-zA-Z\d]{8,20}$", password):
        return True
    else:
        return False

def is_validate_email(email):
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email)
