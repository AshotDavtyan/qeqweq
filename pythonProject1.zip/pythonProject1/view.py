import connDB
from connDB import connection
import query_sql

try:
    with connection.cursor() as cursor:
        cursor.execute(query_sql.call_positions_view)
        res_view1 = cursor.fetchall()
        print("Спмисок должностей:")
        for i in res_view1:
            print(f"Должности: {i['name']}, | Способ оплаты: {i['salary']} ")

        print("_"*20)
        cursor.execute(query_sql.call_employees_view)
        res_view2 = cursor.fetchall()
        print("Сотрудники:")
        for y in res_view2:
            print(f": Имя{y['name']}, | Почта: {y['email']}, | пароль: {y['password']} ")


finally:
    connection.close()